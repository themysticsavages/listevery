"""
listevery

Get every single folder and file in directories and subdirectories!
"""

__version__ = "0.1.6"
__author__ = 'themysticsavages'
__credits__ = 'No one'