"""
listevery

Get every single folder and file in directories and subdirectories!
"""

__version__ = "0.1.3"
__author__ = 'themysticsavages'
__credits__ = 'No one'