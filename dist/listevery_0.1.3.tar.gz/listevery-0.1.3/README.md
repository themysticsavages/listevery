# listevery
![](https://shields.io/badge/pypi-0.1.3-blue) ![](https://shields.io/badge/made%20with-python-lightgray)

__A small program which can list contents of directories and subdirectories, without a depth limit!__ Right now there are a few bugs so I do not recommend using this as a package. Due to my low knowledge of PyPi, you only get files from the installation folder. If you really want to use this, run it in the command line: `python -m listevery [folder]`. Yes, you will get the files and folders where the package is installed. It is formatted similar to this:
```
Folders   Files
[folder1] [file1.txt, file2.py]
[] [thing.mp4]
```
Sorry if you get horribly handled errors, I still need to fix that.

<sub>Have issues? Post them <a href='https://github.com/themysticsavages/listevery/issues/new'>here.</sub>